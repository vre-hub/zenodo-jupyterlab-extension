# zenodo-jupyterlab-extension
Zenodo JupyterLab plugin
